SMDEBUG_GRADIENTS_KEY = "smdebug_gradients"
SMDEBUG_LAYER_OUTPUTS_KEY = "smdebug_layer_outputs"
SMDEBUG_PREFIX = "smdebug_"
